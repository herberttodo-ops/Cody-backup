---
name: openclaw-troubleshooting
description: "Troubleshoot and fix OpenClaw startup failures, migration issues, and database lock problems."
version: 1.0.0
author: Hermes Agent
platforms: [linux]
metadata:
  hermes:
    tags: [openclaw, troubleshooting, migration, nodejs, database, repair]
---

# OpenClaw Troubleshooting

Fix OpenClaw when it won't start, crashes on startup, or displays "Legacy session store requires migration" errors.

## Quick Fixes (try in order)

### 1. Legacy Session Store Migration

**Symptom:** Error message: `"Legacy session store requires migration: /home/herby/.openclaw/agents/main/sessions/sessions.json"`

**Fix:**
```bash
# First check Node.js version (must be >=22.22.3)
node --version

# Migrate: This runs the fix and migrates all legacy state
openclaw doctor --fix
```

**What gets migrated:**
- Session store (JSON → SQLite)
- Plugin catalogs (JSON → SQLite)
- TUI last-session pointers
- Config audit logs
- Crestodian audit logs
- Workspace attestations
- Model credentials

---

### 2. Node.js Version Too Old

**Symptom:** Error on startup: `"Node.js >=22.22.3 <23, >=24.15.0 <25, or >=25.9.0 is required"`

**Fix without sudo (local install):**
```bash
# Download and extract newer Node locally
cd /tmp
curl -fsSL "https://nodejs.org/dist/v22.23.2/node-v22.23.2-linux-x64.tar.xz" -o node.tar.xz
tar -xf node.tar.xz

# Use local Node instead of system Node
export PATH="/tmp/node-v22.23.2-linux-x64/bin:$PATH"

# Verify
node --version

# Now run OpenClaw
doctor --fix
openclaw
```

**Alternative with apt (requires sudo):**
```bash
sudo apt update
sudo apt upgrade -y nodejs
```

---

### 3. Database Locked / Another Gateway Running

**Symptom:** Error: `"another Gateway owns that state directory"` or database locked errors.

**Fix - Kill zombie processes:**
```bash
# Find what's holding the database
fuser ~/.openclaw/state/openclaw.sqlite

# Kill any OpenClaw/Node processes
pkill -9 -f "openclaw"
pkill -9 node

# Wait for processes to die
sleep 3

# Verify database is free
fuser ~/.openclaw/state/openclaw.sqlite
# Should return nothing ("No processes using file")

# Now retry migration
openclaw doctor --fix
```

---

### 4. Start After Migration

Once `doctor --fix` succeeds:

```bash
# Normal start
openclaw

# Or background/detached
openclaw > ~/.openclaw/logs/openclaw.log 2>&1 &

# Use local Node version if system Node is incompatible
export PATH="/tmp/node-v22.23.2-linux-x64/bin:$PATH"
openclaw
```

---

## Diagnostic Commands

### Check what processes are running:
```bash
ps aux | grep openclaw
grep "node" | grep -v grep
```

### Check logs:
```bash
ls -la ~/.openclaw/logs/stability/
cat ~/.openclaw/logs/stability/openclaw-stability-*.json
```

### Check session files:
```bash
ls -la ~/.openclaw/agents/main/sessions/
```

---

## Session Recovery (if history was lost)

If you had to move `sessions.json` for migration, it's backed up to:
```bash
~/.openclaw/backup/sessions.json.bak.YYYYMMDD_HHMMSS
```

Session history is preserved during migration but the format changes from JSON to SQLite. The migration copies all data into the SQLite database.

---

## Common Error Patterns

| Error | Meaning | Fix |
|-------|---------|-----|
| `Legacy session store requires migration` | Old JSON format needs to become SQLite | `openclaw doctor --fix` |
| `Node.js >=22.22.3 required` | System Node too old | Use local Node binary (see #2) |
| `Another Gateway owns that state` | Zombie process holds database lock | Kill all node/openclaw processes |
| `Gateway startup failed` repeated | The failed process keeps crashing | Kill processes, check Node version, then migrate |

---

## Preconditions Checklist

Before troubleshooting, verify:
- [ ] Node.js version compatible (check with `node --version`)
- [ ] No zombie processes holding the database (check with `fuser`)
- [ ] Can access `~/.openclaw/state/openclaw.sqlite` (not locked)
- [ ] Can write to `~/.openclaw/` directory

---

## Support Files

- See `references/` directory for migration logs and session-specific details.
