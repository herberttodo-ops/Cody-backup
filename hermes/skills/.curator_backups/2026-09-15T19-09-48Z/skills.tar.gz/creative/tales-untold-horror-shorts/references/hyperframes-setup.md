# HyperFrames Setup for Tales Untold

## Installation

```bash
# Install Bun (required)
curl -fsSL https://bun.sh/install | bash
export PATH="$HOME/.bun/bin:$PATH"

# Clone and build
git clone https://github.com/heygen-com/hyperframes.git
cd hyperframes
bun install
bun run build
bun link
```

## Render Command

```bash
npx hyperframes render --composition composition.html --format mp4 --fps 30 --quality looks --output output.mp4
```

## CSS Effects Reference

### Vignette (Heavy)
```css
.vignette {
  position: absolute; inset: 0;
  background: radial-gradient(
    ellipse at 50% 38%,
    transparent 0%,
    transparent 12%,
    rgba(0,0,0,0.6) 35%,
    rgba(0,0,0,0.95) 60%,
    rgba(0,0,0,0.98) 100%
  );
  z-index: 5;
}
```

### Film Grain (Visible)
```css
.grain {
  position: absolute; inset: 0;
  opacity: 0.38;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='5' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  z-index: 6;
}
```

### Film Scratches
```css
.scratches {
  position: absolute; inset: 0;
  opacity: 0.12;
  background: repeating-linear-gradient(
    90deg,
    transparent, transparent 1px,
    rgba(255,255,255,0.04) 1px, rgba(255,255,255,0.04) 2px
  );
  z-index: 7;
}
```

## Common Issues

| Issue | Solution |
|-------|----------|
| Images not loading | Use relative paths `./scene1.png` not `../output/` |
| Grain too subtle | Increase opacity to 0.35-0.42 |
| Vignette invisible | Use aggressive stops: transparent 12% → black 98% |
| Render fails | Check `window.__timelines = [tl]` is set |

## Hybrid Pipeline

1. HyperFrames → Renders silent MP4 with motion/effects
2. MoviePy → Adds Adam voice + music + CTA overlay
3. Result → Cinematic visuals + precise audio mixing
