# POYO.ai TTS Discovery & Audio Lessons

## POYO.ai DOES NOT Support ElevenLabs TTS

**Discoverd [2026-09-15]**: POYO.ai lists ElevenLabs as a provider on their marketing page, but their API (`POST /api/generate/submit`) only supports **image and video generation**.

### Failed Model Names Tested
| Model | Result |
|-------|--------|
| `elevenlabs` | 404 — resource_not_found_error |
| `tts-1` | 404 — resource_not_found_error |
| `eleven-tts` | 404 — resource_not_found_error |
| `eleven_multilingual_v2` | 404 — resource_not_found_error |
| `eleven_turbo_v2_5` | 404 — resource_not_found_error |
| `eleven_mono_v1` | 404 — resource_not_found_error |

**Valid POYO models:** `gpt-4o-image`, `flux-schnell`, `kling-3-api`, etc.

### Direct ElevenLabs Also Fails Here
- Key in `.env` (`sk_ac2e...`) returns `invalid_api_key` via both REST API and Python SDK v2.68.0
- Adam voice ID `pNInz6obpgDQGcFmaJgB` is correct, but unreachable

## Audio Lessons

### Crossfade Gap Fix (MoviePy v2)
```python
# WRONG (MoviePy v2):
from moviepy import afx
clip.with_effects([afx.CrossFadeOut(0.15)])

# CORRECT (MoviePy v2):
from moviepy import vfx
clip.with_effects([vfx.CrossFadeOut(0.15)])
```
- `vfx` = video effects module
- `afx` = audio effects (separate module, different functions)

### Music Volume Verification
**Always verify after mixing:**
```bash
ffmpeg -i video.mp4 -vn -af "volumedetect" -f null - 2>&1 | grep mean_volume
```

| Build | Music mean_volume | Verdict |
|-------|-------------------|---------|
| v2/v3 | **-24.7 dB** | Too quiet |
| v3b | **TBD** | Target -15 to -20 dB |

**Fix:** `music.with_volume_scaled(0.3)` instead of `0.1` (3x louder, ~10dB increase)